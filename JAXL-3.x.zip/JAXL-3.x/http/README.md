Jaxl HTTP Stack:
----------------
HTTP Stack implementation includes:

* HTTPClient - Generic HTTP Client
* HTTPServer - Generic HTTP Server
* HTTPRequest - A HTTP Request Object
* HTTPDispatcher - HTTP REST Url Dispatcher
* HTTPMultiPart - HTTP MultiPart Body