Jaxl XMPP XEP's:
----------------
Following XMPP Extensions are available:

* 0030 - Service Discovery
* 0045 - Multi-User Chat
* 0060 - Publish-Subscribe
* 0077 - In-Band Registration
* 0114 - Jabber Component
* 0115 - Entity Capabilities
* 0199 - XMPP Ping
* 0203 - Delayed Delivery
* 0206 - XMPP Over BOSH
* 0249 - Direct MUC Invitation