Jaxl XMPP Stack:
----------------
XMPP Stack implementation includes:

* XMPPStream - RFC 6120 and RFC 6121
* XMPPXep - Abstract XMPP Extension class
* XMPPStanza - Generic Stanza object
* XMPPPres - Generic Presence object
* XMPPMsg - Generic Message object
* XMPPIq - Generic IQ object
* XMPPJid - JabberId object
* XMPPRosterItem - A XMPP Roster Item representation