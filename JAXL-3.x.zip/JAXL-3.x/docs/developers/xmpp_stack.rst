XMPP Stack
==========

XMPP Streams
------------

XMPP Stanza
-----------